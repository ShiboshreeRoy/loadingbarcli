from .loadingbarcli import LoadingBar

__version__ = "0.1.2"
__author__ = "Shiboshree Roy"
__email__ = "shiboshreeroy169@gmail.com"
__github__ = "https://github.com/ShiboshreeRoy"